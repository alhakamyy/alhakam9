//
//  ViewController2.swift
//  hakami9
//
//  Created by mac on ٢ رمضان، ١٤٣٩ هـ.
//  Copyright © ١٤٣٩ هـ mac9. All rights reserved.
//

import UIKit
import WebKit

class ViewController2: UIViewController, UIWebViewDelegate {
    @IBOutlet weak var webSTOR: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()


        webSTOR.delegate = self
        let url = URL(string: "http://alhakam9.com/")
        webSTOR.loadRequest(URLRequest(url: url!))
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func reldod(_ sender: Any)
    {
        webSTOR.reload()
    }
    @IBOutlet weak var activitylndicator: UIActivityIndicatorView!
    
    @available(iOS 2.0, *)
    func webViewDidStartLoad(_ webView: UIWebView){
        activitylndicator.startAnimating()
    }
    

    func webViewDidFinishLoad(_ webView: UIWebView){
        activitylndicator.stopAnimating()
    }

}
