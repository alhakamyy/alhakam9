//
//  ViewController.swift
//  hakami9
//
//  Created by mac on ٢ رمضان، ١٤٣٩ هـ.
//  Copyright © ١٤٣٩ هـ mac9. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func twitter(_ sender: UIButton)
    {
        UIApplication.shared.open(URL(string: "https://twitter.com/FCH56")! as URL, options: [:], completionHandler: nil)
    }
    @IBAction func whatsapp(_ sender: UIButton)
    {
        UIApplication.shared.open(URL(string: "https://api.whatsapp.com/send?phone=966532876509")! as URL, options: [:], completionHandler: nil)    }
    
    
}
