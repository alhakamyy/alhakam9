//
//  ViewController3.swift
//  hakami9
//
//  Created by mac on ٢ رمضان، ١٤٣٩ هـ.
//  Copyright © ١٤٣٩ هـ mac9. All rights reserved.
//

import UIKit
import WebKit

class ViewController3: UIViewController, UIWebViewDelegate {
    @IBOutlet weak var youtube: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        youtube.delegate = self
        let url = URL(string: "http://www.alhakam9.com/")
        youtube.loadRequest(URLRequest(url: url!))
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func reload(_ sender: Any) {
        youtube.reload()
    }
    
    @IBAction func back(_ sender: Any) {
        youtube.goBack()
    }
    
    @IBOutlet weak var activityindicater: UIActivityIndicatorView!
    
    
    func webViewDidStartLoad(_ webView: UIWebView){
        activityindicater.startAnimating()
    }
    
    
    func webViewDidFinishLoad(_ webView: UIWebView){
        activityindicater.stopAnimating()
    }
    

}
